import React from 'react'

function AddHero() {
  return (
    <div>AddHero</div>
  )
}

export default AddHero