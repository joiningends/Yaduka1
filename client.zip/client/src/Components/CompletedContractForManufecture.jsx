import React from 'react'

function CompletedContractForManufecture() {
  return (
    <div>CompletedContractForManufecture</div>
  )
}

export default CompletedContractForManufecture